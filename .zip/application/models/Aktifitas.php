<?php

class Aktifitas extends CI_Model{

    private $_tables = 'tblriwayatnilai';

    public function getAktifitas() {
        $this->db->distinct();
        $this->db->select('nim, nama, tipesoal, tipetugas, tanggal'); 
        $this->db->group_by('nim'); 
        $query = $this->db->get($this->_tables);
        return $query->result();
    }

    public function getCofidentKondisi($nim) {
        $this->db->where('nim', $nim);  
        $query = $this->db->get($this->_tables);
        return $query->result();
    }

     public function getTotalQuestions() {
        $this->db->from('tblriwayatnilai');
        return $this->db->count_all_results();
    }

    public function getTotalCorrectAnswers() {
        $this->db->from('tblriwayatnilai');
        $this->db->where('nilai', 1); 
        return $this->db->count_all_results();
    }

    public function getTotalIncorrectAnswers() {
        $this->db->from('tblriwayatnilai');
        $this->db->where('nilai', 0);
        return $this->db->count_all_results();
    }

    public function getTotalTime() {
        $this->db->select_sum('timer'); 
        $this->db->from('tblriwayatnilai');
        $result = $this->db->get()->row();
        return $result->timer;
    }
    
    
   
}