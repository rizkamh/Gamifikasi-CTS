<!--Footer-part-->

<div class="row-fluid">
	<div id="footer" class="span12"> 2022 &copy; Computational Thinking <a href="home">POLINEMA</a> - Design by JTI Polinema</div>
</div>

<!--end-Footer-part-->