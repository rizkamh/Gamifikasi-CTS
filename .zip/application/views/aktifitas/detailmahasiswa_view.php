<?php $this->load->view('components/head'); ?>
<base href="<?= base_url(); ?>">
<!-- <link rel="stylesheet" href="assets/css/bootstrap-wysihtml5.css" /> -->

<?php $this->load->view('components/navbar'); ?>
<!--sidebar-menu-->

<li><a href="home"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
<li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Manage Mahasiswa</span> <span class="icon icon-chevron-down pull-right" style="margin-right: 5px;"></span></a>
	<ul>
		<li><a href="mahasiswa">Data Mahasiswa</a></li>
		<li><a href="nilai">Nilai</a></li>
	</ul>
</li>
<li class="submenu"> <a href="#"><i class="icon icon-print"></i> <span>Laporan</span> <span class="icon icon-chevron-down pull-right" style="margin-right: 5px;"></span></a>
	<ul>
		<li><a href="laporan/mahasiswalaporan">Laporan Mahasiswa</a></li>
		<li><a href="laporan/nilailaporan">Laporan Nilai</a></li>
	</ul>
</li>
<li class="submenu"> <a href="#"><i class="icon icon-print"></i> <span>Aktifitas</span> <span class="icon icon-chevron-down pull-right" style="margin-right: 5px;"></span></a>
	<ul>
		<li><a href="aktifitas/aktifitasMahasiswa">Aktifitas Mahasiswa</a></li>
	</ul>
</li>

</ul>
</div>
<!--sidebar-menu-->
<div id="content">
	<div id="content-header">
		<div id="breadcrumb"> <a href="home" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
				Home</a> <a href="aktifitas" class="current">Aktifitas</a> </div>
				<h1><span class="icon-briefcase"></span>
			Aktifitas <small>Detail Mahasiswa </small></h1>
	</div>
	<hr>

	<div class="container-fluid">
		<div class="row-fluid pull-left">
			<?php if (!empty($studentActivities)) : ?>
				<table class="table table-striped table-bordered data-table" style="max-width: 300px;">
							<thead>
								<tr>
									<th>Nim</th>
									<th>Nama</th>
								</tr>
							</thead>
					<tbody>
							<tr>
								<td><?php echo $studentActivities[0]->nim; ?></td>
								<td><?php echo $studentActivities[0]->nama; ?></td>
							</tr>
					</tbody>
				</table>
			<?php else : ?>
				<p>No activities found.</p>
			<?php endif; ?>
		</div>

        <div class="row-fluid mt-3">
    <div class="quick-actions_homepage offset2">
        <ul class="quick-actions">
            <li class="bg_lo"> <a href="#"> <i class="icon-file"></i> Total Pertanyaan: <?= $total_questions ?> </a> </li>
            <li class="bg_lo"> <a href="#"> <i class="icon-remove-sign"></i> Jawaban Salah: <?= $total_incorrect ?> </a> </li>
            <li class="bg_lg"> <a href="#"> <i class="icon-thumbs-up"></i> Jawaban Benar: <?= $total_correct ?> </a> </li>
            <li class="bg_lg"> <a href="#"> <i class="icon-time"></i> Waktu: <?= $total_time ?> </a> </li>
        </ul>
    </div>
</div>


        <div class="row-fluid">
			<?php if (!empty($studentActivities)) : ?>
				<table class="table table-striped table-bordered data-table">
							<thead>
								<tr>
									<th>Kategori</th>
									<th>Isi soal</th>
									<th>Confident Tag</th>
									<th>Hasil</th>
									<th>Waktu</th>
								</tr>
							</thead>
					<tbody>
						<?php foreach ($studentActivities as $activity) : ?>
							<tr>
								<td><?php
									if ($activity->tipesoal == 'p') {
										echo 'Soal Pilihan Ganda';
									} elseif ($activity->tipesoal == 'e') {
										echo 'Soal Esai';
									} else {
										echo 'tidak diketahui';
									}
									?></td></td>
								<td><?php echo $activity->isisoal; ?></td>
								<td><?php echo $activity->confident; ?></td>
								<td><?php echo $activity->nilai; ?></td>			
								<td><?php echo $activity->timer; ?></td>			
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p>No activities found.</p>
			<?php endif; ?>
		</div>
	</div>
</div>
</div>

<?php $this->load->view('components/foot'); ?>
<script src="assets/js/app/myfunction.js"></script>
<script src="assets/js/app/soalesai.js"></script>
<?php $this->load->view('components/jsfoot'); ?>


</body>

</html>