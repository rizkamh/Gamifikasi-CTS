<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= $title ?></title>
    <style>
        h1{
            text-align: center;
        }
        table{
            width: 100%;
            border-collapse: collapse;
        }
        td,th {
            /* border: 1px solid black; */
            padding: 10px;
        }
    </style>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<body>